#' smoothcrawler function
#'
#' This function takes a 3x3 grid of cells and averages the values of any cell sitting in between any combination of non-adjacent cells.
#' When applied to a raster file or matrix bigger than 3x3 cells, it starts in the top-left corner and moves by one cell to the right after every averaging cycle. After completing a row, it moves down by one cell and repeats the process until the whole input file is processed.
#'
#' The smoothing function can be applied to the whole input file or only to a selected range of z values.
#'
#' @author Marco Zanon , \email{marco[at]zanon.xyz}
#'
#' @param input An object of class raster or matrix
#' @param range The range of z values affected by the crawler
#' @param passes Number of times this function is applied to the input
#'
#' @return Returns a smoothed matrix or rasted layer.
#'
#' @examples
#'
#' #generate a random raster with the bicubint() function
#'
#' r <- bicubint(x_dims=c(0,200),y_dims=c(0,200), x_cells=200, y_cells=200,
#'      min_z=0,max_z=10,octaves=c(1:3),lacunarity=10,persistence=0.5)
#'
#' #smooth the whole raster
#'
#' r <- smoothcrawler(r, c(0:10))
#'
#' #smooth only selected z ranges
#'
#' r <- smoothcrawler(r, c(4:6))
#' r <- smoothcrawler(r, c(0:3.5))
#'
#' #plot the output
#'
#' library(raster)
#'
#' crs(r) <- CRS('+init=EPSG:6933')
#' slope <- terrain(r, opt='slope')
#' aspect <- terrain(r, opt='aspect')
#'
#' hill <- hillShade(slope, aspect, angle = 45, direction = 45, normalize = TRUE)
#' plot(hill, col = grey(0:100/100), legend = FALSE)
#' plot(r, col = topo.colors(255, alpha = 0.45), add = TRUE)
#' plot(r, col = grey(0:100/100, alpha = 0.45), add = TRUE)
#'
#'
#' @export

smoothcrawler <- function(input, range=c(0,100), passes=1) {

  n=3

  if (class(input)[1] != "matrix" && class(input)[1] != "RasterLayer") {

    message("Input must be an object of class 'RasterLayer' or 'matrix'. Input belongs to class ", class(input)[1], " instead.")

  } else {


  if (passes < 1) {return(input)}

  mx <- as.matrix(input)

  for (p in c(1:passes)) {

  message("Crawler pass ", p)

  #move column by column
  for (i in c(1:(1+(ncol(mx)-n)))) {

  #move row by row
  for (w in c(1:(1+(nrow(mx)-n)))) {


    sub.mx <- mx[c(w:(w+n-1)),c(i:(i+n-1))]

    if (any(sub.mx >= min(range)) && any(sub.mx <= max(range)) ) {

    sub.mx[1,2] <- (sub.mx[1,2] + (sub.mx[1,1]+sub.mx[1,3])/2)/2
    sub.mx[2,1] <- (sub.mx[2,1] + (sub.mx[1,1]+sub.mx[3,1])/2)/2
    sub.mx[2,3] <- (sub.mx[2,3] + (sub.mx[1,3]+sub.mx[3,3])/2)/2
    sub.mx[3,2] <- (sub.mx[3,2] + (sub.mx[3,1]+sub.mx[3,3])/2)/2
    sub.mx[2,2] <- (sub.mx[2,2] + (sub.mx[1,1]+sub.mx[3,3])/2 + (sub.mx[3,1]+sub.mx[1,3])/2 + (sub.mx[2,1]+sub.mx[2,3])/2 + (sub.mx[1,2]+sub.mx[3,2])/2)/5

    mx[c(w:(w+n-1)),c(i:(i+n-1))] <- sub.mx

    }

  } #end row loop

  } #end col loop


  #process raster rim. The outer cells of the map are not smoothed as the inner ones because they
  #go though a lower number of loops.

  #This portion of the script processes the rim again by adding an outer layer of cells (which is not preserved
  #in the final product).

  #top and lower borders
  for (i in c(1:(1+(ncol(mx)-n)))) {

  sub.mx <- matrix(c(mx[1,c(i:(i+n-1))],mx[1,c(i:(i+n-1))],mx[2,c(i:(i+n-1))] ),ncol=n,nrow=n, byrow = TRUE)

  if (any(sub.mx >= min(range)) && any(sub.mx <= max(range)) ) {

  sub.mx[1,2] <- (sub.mx[1,2] + (sub.mx[1,1]+sub.mx[1,3])/2)/2
  sub.mx[2,1] <- (sub.mx[2,1] + (sub.mx[1,1]+sub.mx[3,1])/2)/2
  sub.mx[2,3] <- (sub.mx[2,3] + (sub.mx[1,3]+sub.mx[3,3])/2)/2
  sub.mx[3,2] <- (sub.mx[3,2] + (sub.mx[3,1]+sub.mx[3,3])/2)/2
  sub.mx[2,2] <- (sub.mx[2,2] + (sub.mx[1,1]+sub.mx[3,3])/2 + (sub.mx[3,1]+sub.mx[1,3])/2 + (sub.mx[2,1]+sub.mx[2,3])/2 + (sub.mx[1,2]+sub.mx[3,2])/2)/5

  mx[1,c(i:(i+n-1))] <- sub.mx[2,]

  }

  sub.mx <- matrix(c(mx[nrow(mx)-1,c(i:(i+n-1))],mx[nrow(mx),c(i:(i+n-1))],mx[nrow(mx),c(i:(i+n-1))] ),ncol=n,nrow=n, byrow = TRUE)

  if (any(sub.mx >= min(range)) && any(sub.mx <= max(range)) ) {

  sub.mx[1,2] <- (sub.mx[1,2] + (sub.mx[1,1]+sub.mx[1,3])/2)/2
  sub.mx[2,1] <- (sub.mx[2,1] + (sub.mx[1,1]+sub.mx[3,1])/2)/2
  sub.mx[2,3] <- (sub.mx[2,3] + (sub.mx[1,3]+sub.mx[3,3])/2)/2
  sub.mx[3,2] <- (sub.mx[3,2] + (sub.mx[3,1]+sub.mx[3,3])/2)/2
  sub.mx[2,2] <- (sub.mx[2,2] + (sub.mx[1,1]+sub.mx[3,3])/2 + (sub.mx[3,1]+sub.mx[1,3])/2 + (sub.mx[2,1]+sub.mx[2,3])/2 + (sub.mx[1,2]+sub.mx[3,2])/2)/5

  mx[nrow(mx),c(i:(i+n-1))] <- sub.mx[2,]

  }

  }

  #left and right borders
  for (w in c(1:(1+(nrow(mx)-n)))) {

  sub.mx <- matrix(c(mx[w:(w+n-1),1],mx[w:(w+n-1),1],mx[w:(w+n-1),2]),ncol=n,nrow=n, byrow = FALSE)

  sub.mx[1,2] <- (sub.mx[1,2] + (sub.mx[1,1]+sub.mx[1,3])/2)/2
  sub.mx[2,1] <- (sub.mx[2,1] + (sub.mx[1,1]+sub.mx[3,1])/2)/2
  sub.mx[2,3] <- (sub.mx[2,3] + (sub.mx[1,3]+sub.mx[3,3])/2)/2
  sub.mx[3,2] <- (sub.mx[3,2] + (sub.mx[3,1]+sub.mx[3,3])/2)/2
  sub.mx[2,2] <- (sub.mx[2,2] + (sub.mx[1,1]+sub.mx[3,3])/2 + (sub.mx[3,1]+sub.mx[1,3])/2 + (sub.mx[2,1]+sub.mx[2,3])/2 + (sub.mx[1,2]+sub.mx[3,2])/2)/5

  mx[w:(w+n-1),1] <- sub.mx[,2]


  sub.mx <- matrix(c(mx[w:(w+n-1),ncol(mx)-1],mx[w:(w+n-1),ncol(mx)],mx[w:(w+n-1),ncol(mx)]),ncol=n,nrow=n, byrow = FALSE)

  sub.mx[1,2] <- (sub.mx[1,2] + (sub.mx[1,1]+sub.mx[1,3])/2)/2
  sub.mx[2,1] <- (sub.mx[2,1] + (sub.mx[1,1]+sub.mx[3,1])/2)/2
  sub.mx[2,3] <- (sub.mx[2,3] + (sub.mx[1,3]+sub.mx[3,3])/2)/2
  sub.mx[3,2] <- (sub.mx[3,2] + (sub.mx[3,1]+sub.mx[3,3])/2)/2
  sub.mx[2,2] <- (sub.mx[2,2] + (sub.mx[1,1]+sub.mx[3,3])/2 + (sub.mx[3,1]+sub.mx[1,3])/2 + (sub.mx[2,1]+sub.mx[2,3])/2 + (sub.mx[1,2]+sub.mx[3,2])/2)/5

  mx[w:(w+n-1),ncol(mx)] <- sub.mx[,2]


  }


  }


  if (class(input)[1] == "RasterLayer") {

  output <- raster(nrows = input@nrows, ncols = input@ncols, xmn = input@extent@xmin, xmx = input@extent@xmax, ymn = input@extent@ymin, ymx = input@extent@ymax, crs= input@crs, vals = mx)

  return(output)


  } else if (class(input)[1] == "matrix") {

  return(mx)

  }

  }

}
