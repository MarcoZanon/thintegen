#' bicubint function
#'
#' This function attempts to recreate Perlin-like noise by populating a grid with random values,  then cubic-interpolating between them row wise and column wise.
#' Perlin noise terminology (octaves, lacunarity, persistence) is used for lack of better terms. The original algorithms developed by Ken Perlin are not part of this function.
#'
#' @author Marco Zanon , \email{marco[at]zanon.xyz}
#'
#' @param x_dims A vector containing minimum and maximum x coordinates of the grid
#' @param y_dims Same as 'x_dims', but for the y limits.
#' @param x_cells number of cells along the x axis
#' @param y_cells number of cells along the y axis
#' @param min_z minimum z value of the end product
#' @param max_z maximum z value of the end product
#' @param octaves Number of noise functions. High values have higher frequency and lower amplitude. Can be either a vector (to apply a sequence of octaves) or an integer (to select a specific one)
#' @param lacunarity density of the initial set of random values
#' @param persistence influence exerted  by each successive octave. Values should be between 0 and 1.
#' @param crawler_passes integer. Number of times the function \code{\link{smoothcrawler}} is called.
#' @param crawler_range z values affected by function \code{\link{smoothcrawler}}
#'
#' @return Returns a raster layer
#'
#' @import raster
#'
#' @examples
#'
#' #Create a randomly generated raster layer r with a size of 250x150 grid cells.
#' #Then plot it as a hill shade layer using tools provided with the 'raster' package
#'
#' r <- bicubint(x_dims=c(-100,150),y_dims=c(-100,250), octaves=c(1:3),lacunarity=10, persistence=0.5)
#'
#' library(raster)
#' crs(r) <- CRS('+init=EPSG:6933')
#' slope <- terrain(r, opt='slope')
#' aspect <- terrain(r, opt='aspect')
#' hill <- hillShade(slope, aspect, 40, 270)
#'
#' par(mfrow=c(1,2))
#'
#' plot(hill, col=grey(0:100/100), legend=FALSE, main="hillshade")
#'
#' plot(r ,col=terrain.colors(255), main="elevation")
#'
#' @export





bicubint <- function( x_dims=c(0,100),
                      y_dims=c(0,200),
                      x_cells=max(x_dims)-min(x_dims),
                      y_cells=max(y_dims)-min(y_dims),
                      min_z=0,
                      max_z=1,
                      octaves=c(1:3),
                      lacunarity=10,
                      persistence=0.5,
                      crawler_passes=0,
                      crawler_range=c(min_z,max_z)
) {


  if (x_dims[1]==x_dims[2] | y_dims[1]==y_dims[2] ){ return(message("Minimum and maximum cell coordinates must be different"))}

  if (x_cells <= 1 | x_cells%%1!=0 | y_cells <= 1 | y_cells%%1!=0){ return(message("The number of cells must be an integer > 1"))}




  for(z in octaves) {

  message("processing octave ", z)

  k=1  #counter that keeps increasing the number of rows/columns to populate



  frequency <- lacunarity^(z-1)  #lacunarity basically is the number of starting points to interpolate at the beginning
  #so the maximum lacunarity should not be higher than the number of cells/2 (because bicubic always passes from
  #known values, so it adds new data oonly to empty cells.



  amplitude <- persistence^(z-1) #persistence should be in the range 0-1.




  mx <- matrix(NA , nrow = y_cells, ncol = x_cells)

  x_iterations_done <- NULL

  x_iterations_remaining <- c(1:x_cells)

  y_iterations_done <- NULL

  y_iterations_remaining <- c(1:y_cells)


  if (frequency > x_cells/2 | frequency > y_cells/2) {

    message("frequency too high ( = lacunarity^(octave-1). Try reducing number of octaves, lacunarity or z values, or try increasing raster size")


  } else {

    while (k <= x_cells/2 && k <= y_cells/2) {

      #determine number of x intervals
      x_intervals <- ceiling(seq(0,x_cells,x_cells/(frequency*k)))
      x_intervals[x_intervals < 1] <- 1


      if (is.null(x_iterations_done)) {

        x_intervals <- x_intervals

      } else {

        x_intervals <- x_intervals[!(x_intervals %in% x_iterations_done)]

      }

      x_iterations_done <- c(x_iterations_done, x_intervals)

      x_iterations_remaining <- x_iterations_remaining[!(x_iterations_remaining %in% x_intervals)]


      #determine number of y intervals
      y_intervals <- ceiling(seq(0,y_cells,y_cells/(frequency*k)))
      y_intervals[y_intervals < 1] <- 1

      if (is.null(y_iterations_done)) {

        y_intervals <- y_intervals

      } else {

        y_intervals <- y_intervals[!(y_intervals %in% y_iterations_done)]

      }

      y_iterations_done <- c(y_iterations_done, y_intervals)

      y_iterations_remaining <- y_iterations_remaining[!(y_iterations_remaining %in% y_intervals)]


      #interpolate column wise
      for (i_x in x_intervals)  {

        if (all(is.na(mx[,i_x]))) {

          starting_vals <- sample(c(seq(0,amplitude, amplitude/10)),length(x_intervals), replace=TRUE)

          mx[,i_x] <- cubint(y_intervals,starting_vals, 1) #

        } else {

          mx[,i_x] <- cubint(which(!is.na(mx[,i_x,drop=FALSE])), mx[,i_x][!is.na(mx[,i_x])], 1) #

        }

      }


      #interpolate rowwise
      for (i_y in y_intervals)  {



        mx[i_y,] <- cubint(which(!is.na(mx[i_y,,drop=FALSE])), mx[i_y,][!is.na(mx[i_y,])], 1) #
        #mx[i_y,][!is.na(mx[i_y,])] selects the non-NA value
        #which(!is.na(mx[i_y,,drop=FALSE])) selects the columns with non-NA values
      }


      k <- k*2


    } #while loop


    #cycle through the remaining columns

    tmp_x_mx <- mx

    for (w_x in x_iterations_remaining) {


      tmp_x_mx[,w_x] <- cubint(which(!is.na(tmp_x_mx[,w_x,drop=FALSE])), tmp_x_mx[,w_x][!is.na(tmp_x_mx[,w_x])], 1) #

    }

    #cycle throug the remaining rows

    tmp_y_mx <- mx

    for (w_y in y_iterations_remaining) {


      tmp_y_mx[w_y,] <- cubint(which(!is.na(tmp_y_mx[w_y,,drop=FALSE])), tmp_y_mx[w_y,][!is.na(tmp_y_mx[w_y,])], 1) #

    }

    mx <- (tmp_x_mx + tmp_y_mx) / 2


    r_mx <- raster(nrows = y_cells, ncols = x_cells, xmn = min(x_dims), xmx = max(x_dims), ymn = min(y_dims), ymx = max(y_dims), vals = mx)

    min_new <- 0
    max_new <- amplitude

    min_old <- cellStats(r_mx, "min")
    max_old <- cellStats(r_mx, "max")

    r_output <- ((max_new-min_new)/(max_old-min_old))*(r_mx-max_old)+max_new

    #r_tmp_y <- raster(nrows = max(y_dims), ncols = max(x_dims), xmn = 0, xmx = max(y_dims), ymn = 0, ymx = max(x_dims), vals = tmp_y_mx)

    #r_tmp_x <- raster(nrows = max(y_dims), ncols = max(x_dims), xmn = 0, xmx = max(y_dims), ymn = 0, ymx = max(x_dims), vals = tmp_x_mx)

  }

  eval(parse(text=noquote(paste("r_",(get("z"))," <- r_output", sep=""))))

  } #octaves loop

  r_sum <- raster(nrows = y_cells, ncols = x_cells, xmn = min(x_dims), xmx = max(x_dims), ymn = min(y_dims), ymx = max(y_dims), vals = 0)

  for (q in octaves) {

  r_sum <- r_sum + eval(parse(text=noquote(paste("r_",(get("q")), sep=""))))


  }

  min_new <- min_z
  max_new <- max_z

  min_old <- cellStats(r_sum, "min")
  max_old <- cellStats(r_sum, "max")

  r_sum <- ((max_new-min_new)/(max_old-min_old))*(r_sum-max_old)+max_new

  r_sum <- smoothcrawler(r_sum, crawler_range, crawler_passes)

  return(r_sum)



} #end function
