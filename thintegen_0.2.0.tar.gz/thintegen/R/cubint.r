#' cubint function
#'
#' This function interpolates within a given set of points preserving their original values.
#'
#' The interpolation formula was taken from https://www.paulinternet.nl/?page=bicubic and implemented without too much thinking.
#'
#'
#' @author Marco Zanon , \email{marco[at]zanon.xyz}
#'
#' @param y_vals,x_vals Vectors giving the coordinates of the points to be interpolated.
#' @param samp Sampling rate
#'
#' @return Returns a vector of y values at the desired sampling rate.
#'
#'
#' @examples
#'
#' #Interpolate smoothly between given points preserving their original values.
#'
#' x <- c(1,5,10,20)
#' y <- c(0.5,7,5,10)
#'
#' samp <- 0.1
#'
#' v <- cubint(x,y,samp)
#'
#' plot(x= seq(min(x), max(x),samp), y= v, type="o", cex=0.5, ylab="y", xlab="x")
#' points(x,y,col="red", pch=19)
#'
#' @export



cubint <- function(x_vals, y_vals, samp){

  #Cubic interpolation
  #formula taken from https://www.paulinternet.nl/?page=bicubic

  cubic_formula <- function(p, x)
  {p[2] + 0.5 * x*(p[3] - p[1] + x*(2.0*p[1] - 5.0*p[2] + 4.0*p[3] - p[4] + x*(3.0*(p[2] - p[3]) + p[4] - p[1])))}

  output <- NA

  if (length(y_vals) <= 2 | length(x_vals) <= 2)  {

    #message("length(y_vals): ",length(y_vals), " - length(x_vals): ",length(x_vals))

    w <- c(y_vals[1],y_vals[1],y_vals[2],y_vals[2])

    intervals <- seq(x_vals[1],x_vals[2],samp)
    sampc.intervals <- (intervals-min(intervals))/(max(intervals)-min(intervals))

    output <- c(output, cubic_formula(w,sampc.intervals))

    return(output[!is.na(output)])

  } else {

  for (i in c(1:length(y_vals))) {

    #message("i = ", i)

    if (i == 1) {

      #message("initial i")

      w <- c(y_vals[1],y_vals[1],y_vals[2],y_vals[3])

      intervals <- seq(x_vals[1],x_vals[2],samp)
      sampc.intervals <- (intervals-min(intervals))/(max(intervals)-min(intervals))

      output <- c(output, cubic_formula(w,sampc.intervals))

    } else if (i == length(y_vals)-1) {

      #message("penultimate i")

      w <- c(y_vals[length(y_vals)-2],y_vals[length(y_vals)-1],y_vals[length(y_vals)],y_vals[length(y_vals)])
      intervals <- seq(x_vals[length(x_vals)-1],x_vals[length(x_vals)],samp)
      sampc.intervals <- (intervals-min(intervals))/(max(intervals)-min(intervals))
      output <- c(output, cubic_formula(w,sampc.intervals)[-1])

    } else if (i == length(y_vals)) {

      #message("last i")

      return(output[!is.na(output)])

    } else {

      #message("running - i = ", i)

      w <- c(y_vals[i-1],y_vals[i],y_vals[i+1],y_vals[i+2])
      intervals <- seq(x_vals[i],x_vals[i+1],samp)
      sampc.intervals <- (intervals-min(intervals))/(max(intervals)-min(intervals))
      output <- c(output, cubic_formula(w,sampc.intervals)[-1])

    }

  } #for loop

} #first if loop

} #end function

